package com.humanbooster.g5.ideanoval.jst;

/**
 * 
 * @author Sylvain
 *
 */
public class Main {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
