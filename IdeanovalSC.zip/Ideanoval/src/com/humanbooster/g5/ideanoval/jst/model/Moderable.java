package com.humanbooster.g5.ideanoval.jst.model;

public interface Moderable {
	public void activate();
	public void deativate();
}
